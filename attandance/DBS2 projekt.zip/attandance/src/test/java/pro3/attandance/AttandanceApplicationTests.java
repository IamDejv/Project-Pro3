package pro3.attandance;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AttandanceApplicationTests {

    @Test
    void contextLoads() {
    }

}
