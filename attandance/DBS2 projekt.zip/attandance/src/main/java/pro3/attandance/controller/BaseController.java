package pro3.attandance.controller;


import java.util.List;

public interface BaseController<T> {

     List<T> getAll();
}
